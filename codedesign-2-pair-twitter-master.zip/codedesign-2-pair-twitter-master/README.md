# Twitter Data Visualisation
Pulling info off twitter to create a meme. 

#
